def raya(caracter,longitud):
    for i in range(longitud):
        print(caracter,end="")
    print()
c=input("ingresar caracter: ")
l=int(input("ingresar longitud: "))
raya(c,l)