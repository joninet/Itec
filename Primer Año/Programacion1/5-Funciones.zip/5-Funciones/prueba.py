# texto="Quiero comer manzanas, solamente manzanas."

# nuevaF=""
# for x in range(len(texto)):
#     letra=texto[x]
#     if letra not in ".,":
#         nuevaF+=letra
# print(nuevaF)

# def foo():
#     nombres=["jon","aaa"]
#     sexos=["ajaj","kskks"]
#     return nombres,sexos
# nn,ss=foo()
# print(ss)
numero="23"
for x in range(len(numero)):
    num=numero[x]
    contador=0
    contador+=int(num)
print(contador)
