from funciones import inputInt

n = inputInt("Ingrese un entero entre 3 y 7: ", 3, 7)
m = inputInt("Cualquier número real: ")
maxito = inputInt("Ingresar un entero, maximo=1000: ", maxi=1000)
minito = inputInt("Ingresar un entero, minimo=1000: ", 1000)
